export const Footer = () => {
    return <div>Footer</div>;
};