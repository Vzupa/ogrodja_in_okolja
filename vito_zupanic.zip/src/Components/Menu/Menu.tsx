import { ekipa } from "../../Modules/primer"

export function Menu(){
    return <h1 className="menu-wrapper">{ekipa.ime}</h1>
};