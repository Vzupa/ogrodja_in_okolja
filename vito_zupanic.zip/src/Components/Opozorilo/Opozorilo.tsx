export const OpozoriloKomponent = () => {
    return (
        <div>
            Ekipa nima dovolj igralcev
        </div>
    );
};