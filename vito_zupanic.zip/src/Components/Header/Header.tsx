import * as React from 'react';

export const Header = (): JSX.Element => {
    return (
        <React.Fragment>
            <div className="header" >Header</div>
        </React.Fragment>
        );
};
