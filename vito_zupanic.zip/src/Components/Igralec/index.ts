export { IgralecInfo } from "./Igralec";

