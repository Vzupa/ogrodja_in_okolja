export function Noga(): JSX.Element{
    return <div className="footer">Avtor: Vito Zupanič</div>
}