export const InfoKomponent = () => {
    return (
        <div>
            Ekipa ima dovolj igralcev
        </div>
    );
};